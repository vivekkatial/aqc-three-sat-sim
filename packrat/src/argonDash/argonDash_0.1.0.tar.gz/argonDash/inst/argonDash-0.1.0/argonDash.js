$(function () {
    $('#sidebar-menu .nav-link:eq(0)').tab('show');
    $('.tab-pane:eq(0)').addClass('show active');
});